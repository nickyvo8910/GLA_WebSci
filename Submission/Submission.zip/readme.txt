Each file would collect the twitter data for the purpose
Need to put in Twitter API Token for it to work
Modifying the _RUNNINGTIME for the running time
Can only run at most 2 streams API and 1 REST API at any time